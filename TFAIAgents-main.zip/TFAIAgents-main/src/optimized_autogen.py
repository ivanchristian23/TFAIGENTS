\# optimized_autogen.py

import autogen

from code_quality_agent import code_quality_agent

from debugging_agent import debugging_agent

manager = autogen.GroupChatManager()

group_chat = autogen.GroupChat(agents=\[code_quality_agent,
debugging_agent\], messages=\[\])

manager.manage(group_chat)