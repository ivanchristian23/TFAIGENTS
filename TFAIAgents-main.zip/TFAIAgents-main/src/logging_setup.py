# logging_setup.py

import logging

logging.basicConfig(
    filename='code_review_logs.log',
    level=logging.INFO,
    format='%(asctime)s %(message)s'
)

logging.info('Agent interaction logged')