\# sentiment_analysis.py

from azure.ai.textanalytics import TextAnalyticsClient

from azure.core.credentials import AzureKeyCredential

def sentiment_analysis(review_text):

client =
TextAnalyticsClient(endpoint="\<Your_Text_Analytics_Endpoint\>",
credential=AzureKeyCredential("\<Your_Key\>"))

documents = \[review_text\]

response = client.analyze_sentiment(documents=documents)\[0\]

return response.sentiment

sentiment = sentiment_analysis("This code is excellent!")

print(sentiment)