# code_quality_agent.py
    
import os
import autogen

code_quality_agent = autogen.AssistantAgent(
    name="CodeQualityAgent",
    llm_config={
        "api_key": os.getenv('AZURE_OPENAI_KEY'),
        "endpoint": os.getenv('AZURE_OPENAI_ENDPOINT')
    }
)