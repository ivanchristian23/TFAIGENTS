# github_integration.py

from github import Github

def fetch_github_code(repo_name, file_path, access_token):

g = Github(access_token)

repo = g.get_repo(repo_name)

file_content = repo.get_contents(file_path)

return file_content.decoded_content.decode('utf-8')

code_snippet = fetch_github_code(

r"C:\Users\sadha\OneDrive\Documents\Technofocus\Project 2- Agentic AI
Code reviwer and Mentor\repo",

r"C:\Users\sadha\OneDrive\Documents\Technofocus\Project 2- Agentic AI
Code reviwer and
Mentor\repo\get-started-with-ai-agents\github_integration.py",

"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"
)