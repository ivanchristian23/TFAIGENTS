# debugging_agent.py

import os
import autogen

debugging_agent = autogen.AssistantAgent(
    name="DebuggingAgent",
    llm_config={
        "api_key": os.getenv('AZURE_OPENAI_KEY'),
        "endpoint": os.getenv('AZURE_OPENAI_ENDPOINT')
    }
)