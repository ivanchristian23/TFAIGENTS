# main.py
import autogen
from code_quality_agent import code_quality_agent
from debugging_agent import debugging_agent

user_proxy = autogen.UserProxyAgent("developer", human_input_mode="TERMINATE", llm_config={})
user_proxy.initiate_chat(code_quality_agent, message="Review this Python function for quality.")